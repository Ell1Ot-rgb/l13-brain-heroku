# Reporte de Estado de Cuotas — Antigravity CLI

**Cuenta:** `caracolbob878@gmail.com`

- **Grupo GEMINI (Flash & Pro):**
  - Semanal: **38.50%** restante (Reinicia en 44h 36m).
  - 5 Horas: **91.86%** restante (Reinicia en 24m).

- **Grupo CLAUDE y GPT (Opus, Sonnet, GPT-OSS):**
  - Semanal: **100.00%** (Completa).
  - 5 Horas: **100.00%** (Completa).
