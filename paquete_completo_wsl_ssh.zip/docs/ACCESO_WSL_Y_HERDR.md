# Guía de Acceso SSH y Herdr a WSL2 (DESKTOP-OK8F176)

## 📌 Datos de Conexión
- **VPS Gateway:** `159.203.164.103`
- **Puerto WSL2:** `2222`
- **Usuario WSL2:** `elliot`
- **Llave Privada SSH:** `../keys/id_ed25519_nethunter`
- **Puerto PC .35:** `2235` (Usuario: `Elliot`)

## 🚀 Uso de Scripts
1. `./scripts/connect-wsl-ssh.sh`: Conexión directa SSH a la terminal de WSL2.
2. `./scripts/connect-herdr.sh`: Acoplarse a la sesión activa de Herdr (`default`).
3. `./scripts/reactivate-tunnels.sh`: Reactivar túneles inversos si se corta la conexión.
