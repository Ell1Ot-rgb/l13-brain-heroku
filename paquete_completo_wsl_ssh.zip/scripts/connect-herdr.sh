#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
ssh -t -p 2222 -i "$DIR/../keys/id_ed25519_nethunter" elliot@159.203.164.103 "herdr session attach default"
