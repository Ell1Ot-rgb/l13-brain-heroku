#!/usr/bin/env bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
ssh -f -N -o ServerAliveInterval=30 -o ServerAliveCountMax=3 -o ExitOnForwardFailure=yes -R 0.0.0.0:2222:127.0.0.1:22 -R 0.0.0.0:2235:192.168.1.35:22 -i "$DIR/../keys/id_ed25519_nethunter" root@159.203.164.103
